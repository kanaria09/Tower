﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//管理炮塔的攻击
public class Turret : MonoBehaviour
{
    public List<GameObject> enemys = new List<GameObject>(); //存放所有在攻击范围内的敌人
    
    //炮塔加圆形碰撞器和刚体
    //判断敌人是否进入炮塔攻击的触发器
    void OnTriggerEnter(Collider col)
    {
        if (col.tag == "Enemy")   //将敌人的标签设为Enemy
        {
            enemys.Add(col.gameObject);
        }
    }

    //离开触发器
    void OnTriggerExit(Collider col)
    {
        if (col.tag == "Enemy")
        {
            enemys.Remove(col.gameObject);
        }
    }

    public float attackRateTime = 1; //炮塔攻击的速率 多少秒攻击一次
    private float timer = 0;    //计时器 判断攻击时间是否到了

    public GameObject bulletPrefab;  //子弹预制体
    public Transform firePosition;   //炮弹的位置

    public Transform head;   //炮塔的头部

    public bool useLaser = false;   //是否用激光攻击
    public float damageRate = 70;   //激光一秒钟伤害

    public LineRenderer laserRenderer;   //射线组件

    //public GameObject laserEffect;   //激光特效

    void Start()
    {
        timer = attackRateTime;
    }

    void Update()
    {
        
        //控制炮塔头部的旋转
        if (enemys.Count > 0 && enemys[0] != null)  //炮塔攻击范围内有敌人
        {
            Vector3 targetPosition = enemys[0].transform.position;   //获取目标敌人的位置
            targetPosition.y = head.position.y;    //炮塔的头部与目标敌人的y轴位置一致
            head.LookAt(targetPosition);  //注视目标敌人的位置
        }

        if (useLaser == false)
        {
            timer += Time.deltaTime;
            if (enemys.Count > 0 && timer >= attackRateTime)
            {
                timer = 0;
                Attack();
            }
        }

        else if (enemys.Count > 0)    //攻击范围内有敌人
        {
            if (laserRenderer.enabled == false)
                laserRenderer.enabled = true;

            if (enemys[0] == null)   //
            {
                UpdateEnemys();   //更新敌人数量
            }

            if (enemys.Count > 0)
            {
                //（三维位置（开始的位置，结束位置））
                laserRenderer.SetPositions(new Vector3[] { firePosition.position, enemys[0].transform.position });
                enemys[0].GetComponent<Enemy>().TakeDamage(damageRate * Time.deltaTime);   //对敌人的伤害
                //laserEffect.transform.position = enemys[0].transform.position;   //播放特效
                Vector3 pos = transform.position;  //取得炮塔的位置
                pos.y = enemys[0].transform.position.y;   //y轴与敌人一样
                //laserEffect.transform.LookAt(pos);  //特效面朝激光
            }
        }

        //激光不攻击的时候
        else
        {
            //laserEffect.SetActive(false);
            laserRenderer.enabled = false;   //不显示激光
        }
    }

    //炮塔发射子弹攻击
    void Attack()
    {
        //判断范围内的敌人数量是否为空
        if (enemys[0] == null)  
        {
            UpdateEnemys();
        }

        //范围内敌人数组不为空
        if (enemys.Count > 0)
        {
            GameObject bullet = GameObject.Instantiate(bulletPrefab, firePosition.position, firePosition.rotation);  //得到子弹的预制体
            bullet.GetComponent<Bullet>().SetTarget(enemys[0].transform);   //攻击范围内的第一个敌人
        }

        //范围内敌人数组为空
        else
        {
            timer = attackRateTime;
        }
    }

    //更新范围内的敌人数组
    void UpdateEnemys()
    {
        //enemys.RemoveAll(null);   //移除所有为空的元素

        List<int> emptyIndex = new List<int>();   //定义一个新的列表 保存所有的空元素
        //遍历范围内敌人数组
        for (int index = 0; index < enemys.Count; index++)
        {
            if (enemys[index] == null)    //敌人数组为空
            {
                emptyIndex.Add(index);  //将为空的元素加到列表里
            }
        }

        //移除列表里所有的空元素
        for (int i = 0; i < emptyIndex.Count; i++)
        {
            enemys.RemoveAt(emptyIndex[i] - i);
        }
    }

}
