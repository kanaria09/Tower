﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;   
using UnityEngine.UI;

//炮台建造管理类
public class BuildManager : MonoBehaviour
{
    //三种炮塔的数据类
    public TurretData laserTurretData;   
    public TurretData missileTurretData;
    public TurretData standardTurretData;

    private TurretData selectedTurretData;  //表示当前选择的炮台(要建造的炮台)

    private MapCube selectedMapCube;   ////表示当前选择的炮台(场景中的游戏物体)

    public Animator moneyAnimator;  //资金不足时的动画
    public Text moneyText;   //显示资金的文本
    private int money = 1000;   //资金

    public GameObject upgradeCanvas;   //控制升级拆除面板的Canvas
    private Animator upgradeCanvasAnimator;   //升级面板出现和隐藏的动画
    public Button buttonUpgrade;   //升级的按钮

    //游戏更新
    void Start()
    {
        //获取升级面板的动画控制器
        upgradeCanvasAnimator = upgradeCanvas.GetComponent<Animator>();
    }

    //游戏更新
    void Update()
    {
        if (Input.GetMouseButtonDown(0))  //如果鼠标按下（0按下  1弹起）
        {
            if (EventSystem.current.IsPointerOverGameObject() == false)  //鼠标是否按在UI上
            {
                //开发炮台的建造  鼠标点击mapcube
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);  //射线检测 鼠标的点转换为射线
                RaycastHit hit;   //射线检测目标
               
                //1000代表距离  LayerMask.GetMask("MapCube") layer层中的MapCube层
                bool isCollider = Physics.Raycast(ray, out hit, 1000, LayerMask.GetMask("MapCube"));

                if (isCollider)  //isCollider判断鼠标是否与mapcube发生碰撞
                {
                    MapCube mapCube = hit.collider.GetComponent<MapCube>();   //获得mapcube管理类

                    if (selectedTurretData != null && mapCube.turretGo == null)  //如果选择了炮塔 并且cube上没有炮塔才可以创建炮塔
                    {
                        if (money > selectedTurretData.cost)  //资金大于炮塔的价格 说明可以创建炮塔
                        {
                            ChangeMoney(-selectedTurretData.cost);   //减去炮塔的价格
                            mapCube.BuildTurret(selectedTurretData);   //创建炮塔
                        }

                        else   //不可以创建炮塔
                        {
                            moneyAnimator.SetTrigger("Flicker");  //播资金闪烁的动画 提示钱不够
                        }
                    }


                    else if (mapCube.turretGo != null)
                    {
                        // 升级处理
                        ShowUpgradeUI(mapCube.transform.position, mapCube.isUpgraded);
                        if (mapCube == selectedMapCube && upgradeCanvas.activeInHierarchy)   //当前点击的cube上已有炮塔 并且已经升级过了
                        {
                            StartCoroutine(HideUpgradeUI());   //再点击一次cube就隐藏升级拆除面板
                        }
                        else
                        {
                            ShowUpgradeUI(mapCube.transform.position, mapCube.isUpgraded);
                        }
                        selectedMapCube = mapCube;   //当前点击的cube等于之前保存炮塔的cube
                    }
                }
            }
        }
    }

    //资金的管理
    public void ChangeMoney(int change = 0)
    {
        money += change;   //change改变的值
        moneyText.text = "$ " + money;   //显示文本
    }

    //监听Laser炮塔是否被选择
    public void OnLaserSelected(bool isOn)
    {
        if (isOn)   //isOn 表示被选择
        {
            selectedTurretData = laserTurretData;
        }
    }

    //监听Missile炮塔是否被选择
    public void OnMissileSelected(bool isOn)
    {
        if (isOn)
        {
            selectedTurretData = missileTurretData;
        }
    }

    //监听Standar炮塔是否被选择
    public void OnStandardSelected(bool isOn)
    {
        if (isOn)
        {
            selectedTurretData = standardTurretData;
        }
    }

    //显示ui   是否禁用升级按钮
    void ShowUpgradeUI(Vector3 pos, bool isDisableUpgrade = false)
    {
        StopCoroutine("HideUpgradeUI");   //停止协程
        upgradeCanvas.SetActive(false);
        upgradeCanvas.SetActive(true);    //画布的显示
        upgradeCanvas.transform.position = pos;  //显示的位置
        buttonUpgrade.interactable = !isDisableUpgrade;   //升级按钮是否禁用
    }

    //隐藏ui  协程
    IEnumerator HideUpgradeUI()
    {
        upgradeCanvasAnimator.SetTrigger("Hide");  //播放升级面板隐藏的动画
        yield return new WaitForSeconds(0.8f);   //
        upgradeCanvas.SetActive(false);   //隐藏画布
    }

    //升级按钮按下
    public void OnUpgradeButtonDown()
    {
        //判断资金是否足够
        if (money >= selectedMapCube.turretData.costUpgraded)  
        {
            //可以升级
            ChangeMoney(-selectedMapCube.turretData.costUpgraded);
            selectedMapCube.UpgradeTurret();
        }
        else
        {
            moneyAnimator.SetTrigger("Flicker");
        }

        StartCoroutine(HideUpgradeUI());
        //selectedMapCube.UpgradeTurret();
        //StartCoroutine(HideUpgradeUI());

    }

    //拆除按钮按下
    public void OnDestroyButtonDown()
    {
        selectedMapCube.DestroyTurret();
        StartCoroutine(HideUpgradeUI());
        ChangeMoney(50);
    }

}