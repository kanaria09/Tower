﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//炮塔数据类（类型 价格）
[System.Serializable]    //可序列化
public class TurretData
{
    public GameObject turretPrefab;   //炮台的预制体
    public int cost;    //炮塔的价格
    public GameObject turretUpgradedPrefab;   //升级后的炮塔预制体
    public int costUpgraded;   //升级炮塔的价格
    public TurretType type;   //炮塔的类型
}

//枚举类型
public enum TurretType
{
    //三种炮塔的类型
    LaserTurret,    
    MissileTurret,
    StandardTurret
}