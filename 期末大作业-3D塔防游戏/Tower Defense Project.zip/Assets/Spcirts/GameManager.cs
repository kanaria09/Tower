﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    public GameObject endUI;   //结束界面
    public Text endMessage;    //文字文本

    public static GameManager Instance;
    private EnemySpawner enemySpawner;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            return;
        }
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
    }
        void Awake()
    {
        Instance = this;
        enemySpawner = GetComponent<EnemySpawner>();
    }

    public void Win()
    {
        endUI.SetActive(true);
        endMessage.text = "胜 利";
    }
    public void Failed()
    {
        enemySpawner.Stop();  //停止生产敌人
        endUI.SetActive(true);
        endMessage.text = "失 败";
    }

    //退出按钮
    public void OnButtonRetry()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
 //重新加载场景
    }

    //重玩按钮
    public void OnButtonMenu()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);  //重新加载场景
    }
}
