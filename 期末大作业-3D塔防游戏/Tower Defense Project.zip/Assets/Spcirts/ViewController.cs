﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//通过键盘的上下左右控制摄像机的移动
//通过鼠标滑轮滚动控制摄像机的缩放
public class ViewController : MonoBehaviour
{
	public float speed = 1;   //摄像头移动的速度
	public float mouseSpeed = 60;

	void Update()
    {
		float h = Input.GetAxis("Horizontal");    //Horizontal是键盘上左右的的按键
		float v = Input.GetAxis("Vertical");      //Vertical是键盘的上下按键的
		float mouse = Input.GetAxis("Mouse ScrollWheel");

		transform.Translate(new Vector3(h * speed, mouse * mouseSpeed, v * speed) * Time.deltaTime, Space.World);
		//Vector3移动的三维坐标（x,y,z）
		//Time.deltaTime当前帧的时间
		// Space.World世界坐标

	}

}
