﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CanvasSitting : MonoBehaviour
{
    public GameObject SettingPanel;     //设置面板
    public bool isShow;                 //是否显示
    public GameObject ControlButton;    //暂停/继续游戏的按钮
    public GameObject ControlButton1;   //开始/退出游戏的按钮
    public Text BtnTitle;               //暂停/继续游戏按钮显示的文字
    public Text BtnTitle1;              //开始/退出游戏按钮显示的文字
    public bool BtnState = false;       //暂停/继续游戏按钮的状态
    public bool BtnState1 = false;      //开始/退出游戏按钮的状态

    void Start()
    {
        Time.timeScale = 0f;
        //寻找组件,注册点击事件
        ControlButton.GetComponent<Button>().onClick.AddListener(ControlTime);
        ControlButton1.GetComponent<Button>().onClick.AddListener(OnExitGame);

    }

    void Update()
    {
        SettingMenu();
    }

    //设置面板
    public void SettingMenu()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            isShow = !isShow;
            SettingPanel.gameObject.SetActive(isShow);
        }
    }

    //暂停和继续游戏
    public void ControlTime()
    {
        //如果点击了
        if (BtnState)
        {
            BtnState = false;
            BtnTitle.text = "暂停";
            //将时间设置为0,画面会停止运动,慢动作可以设置为0.5f
            Time.timeScale = 1f;
        }
        else
        {
            BtnState = true;
            BtnTitle.text = "继续";
            //将时间设置为0,画面会停止运动,慢动作可以设置为0.5f
            Time.timeScale = 0f;
        }
    }

    //开始/退出游戏
    public void OnExitGame()
    {
        if (BtnState1)
        {
#if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }
        else
        {
            BtnState1 = true;
            BtnTitle1.text = "退出";
            //将时间设置为0,画面会停止运动,慢动作可以设置为0.5f
            Time.timeScale = 1f;
        }
    }
}