﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{

    public int damage = 50;   //子弹的伤害

    public float speed = 20;   //子弹的速度

    public GameObject explosionEffectPrefab;   //子弹爆炸的效果

    private float distanceArriveTarget = 1.0f;   //子弹与敌人的距离

    private Transform target;   //子弹打击的目标

    //实例化目标
    public void SetTarget(Transform _target)
    {
        this.target = _target;
    }

    void Update()
    {
        if (target == null)   //子弹击打的目标为空
        {
            Die();   //调用销毁函数
            return;
        }

        transform.LookAt(target.position);   //子弹面向目标的位置
        transform.Translate(Vector3.forward * speed * Time.deltaTime);  //子弹移动

        Vector3 dir = target.position - transform.position;   //三维向量dir = 敌人的位置-当前子弹的位置
        if (dir.magnitude < distanceArriveTarget)    //dir.magnitude向量的长度
        {
            target.GetComponent<Enemy>().TakeDamage(damage);   //目标敌人扣血
            Die();   //调用 创建子弹爆炸的特效 销毁特效和子弹 函数
        }
    }

    //创建子弹爆炸的特效 销毁特效和子弹
    void Die()
    {
        GameObject effect = GameObject.Instantiate(explosionEffectPrefab, transform.position, transform.rotation);   //创建子弹爆炸的特效
        Destroy(effect, 1);   //销毁子弹爆炸特效
        Destroy(this.gameObject);   //销毁子弹
    }

}

