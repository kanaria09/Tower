﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//保存每一波敌人生成的属性
[System.Serializable]  //可视化
public class Wave 
{
    public GameObject enemyPrefab;
    public int count;  //生成几个敌人
    public float rate;   //生成一个敌人的间隔时间

}
