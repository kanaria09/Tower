﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Waypoints : MonoBehaviour 
{
	public static Transform[] positions;   //静态数组，存储路径点

	void Awake()
    {
		positions = new Transform[transform.childCount];   //存储的waypoint子节点的路径坐标（自身不包括）
		for(int i = 0; i < positions.Length;i++)   
        {
			positions[i] = transform.GetChild(i);   //获得子孩子的坐标
        }
    }
	
}
