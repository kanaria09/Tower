﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

//管理mapcube
public class MapCube : MonoBehaviour
{
    [HideInInspector]  //隐藏面板
    public GameObject turretGo;//保存当前cube身上的炮台

    [HideInInspector]
    public TurretData turretData;   //炮塔的数据

    [HideInInspector]
    public bool isUpgraded = false;   //判断炮塔是否升级过

    public GameObject buildEffect;   //粒子系统

    private Renderer renderer;   //获取cube的颜色

    void Start()
    {
        renderer = GetComponent<Renderer>();
    }

    //创建炮塔
    public void BuildTurret(TurretData turretData)
    {
        this.turretData = turretData;
        isUpgraded = false;

        //在鼠标点击的cube上创建炮塔
        turretGo = GameObject.Instantiate(turretData.turretPrefab, transform.position, Quaternion.identity);

        //创建炮塔时触发粒子效果
        GameObject effect = GameObject.Instantiate(buildEffect, transform.position, Quaternion.identity);

        Destroy(effect, 1.5f);
    }

    //炮塔升级
    public void UpgradeTurret()
    {
        if (isUpgraded == true) return;   //升级标记
        Destroy(turretGo);   //销毁之前的炮塔
        isUpgraded = true;
        turretGo = GameObject.Instantiate(turretData.turretUpgradedPrefab, transform.position, Quaternion.identity);
        GameObject effect = GameObject.Instantiate(buildEffect, transform.position, Quaternion.identity);
        Destroy(effect, 1.5f);
    }

    //销毁炮塔
    public void DestroyTurret()
    {
        Destroy(turretGo);
        isUpgraded = false;
        turretGo = null;   //cube上为空
        turretData = null;
        GameObject effect = GameObject.Instantiate(buildEffect, transform.position, Quaternion.identity);
        Destroy(effect, 1.5f);
    }

    //鼠标进入cube
    void OnMouseEnter()
    {
        //cube上面没有炮塔 && 鼠标是否放在ui上
        if (turretGo == null && EventSystem.current.IsPointerOverGameObject() == false)
        {
            //将cube的颜色设置为红色
            renderer.material.color = Color.red;
        }
    }

    //鼠标移出cube
    void OnMouseExit()
    {
        renderer.material.color = Color.white;
    }
}
